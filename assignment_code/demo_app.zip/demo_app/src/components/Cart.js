import { React } from "react";

const Cart = () => {
    return (
        <>
            <h2>This is a cart page</h2>
        </>
    )
}

export default Cart;